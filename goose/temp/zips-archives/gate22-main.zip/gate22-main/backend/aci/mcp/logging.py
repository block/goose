from enum import StrEnum


class LogEvent(StrEnum):
    SEARCH_TOOLS = "search_tools"
    EXECUTE_TOOL = "execute_tool"
