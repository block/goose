"""
Service layer for control plane business logic.
"""

from .email_service import EmailService

__all__ = ["EmailService"]
