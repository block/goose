export const SDK_NAME = 'openlit';
export const DEFAULT_ENVIRONMENT = 'default';
export const DEFAULT_APPLICATION_NAME = 'default';
export const INSTRUMENTATION_PREFIX = '@openlit';
export const TELEMETRY_SDK_NAME = 'opentelemetry';
export const OPENLIT_URL = 'http://127.0.0.1:3000';
