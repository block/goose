"use client";
import Explorer from "./explorer/page";

export default function DashboardPage() {
	return <Explorer />;
}
