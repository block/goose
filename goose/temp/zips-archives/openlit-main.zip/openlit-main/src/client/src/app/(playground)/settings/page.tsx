import { redirect } from 'next/navigation'

export default function DefaultSettingsPage() {
  redirect('/settings/evaluation')
}