Hi!

Thanks very much for your submission to Ansible. It means a lot to us.

We are interested in this idea and would like to see a wider discussion on it on one of our lists.
Reasons for this include:

* INSERT REASONS!

Because this project is very active, we're unlikely to see comments made on closed tickets and we lock them after some time.
Please post your idea on the Ansible Forum so we can discuss it with the wider group.

* [Ansible Core on the Ansible Forum](https://forum.ansible.com/tag/ansible-core)

For other alternatives, check this page for a more complete list of communication channels and their purposes:

* <https://docs.ansible.com/ansible/latest/community/communication.html>

Thank you once again for this and your interest in Ansible!
